<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $botToken = "6362171314:AAEnB_4DdwDkCEjKmRTAH_5bTSqubvwrev8";
    $chatId = "-1001926682773";
    $message = $_POST['message'];

    $data = [
        'chat_id' => $chatId,
        'text' => $message
    ];

    file_get_contents("https://api.telegram.org/bot$botToken/sendMessage?" . http_build_query($data));
}
?>
